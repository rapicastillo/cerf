
This module provides new styles for Views module to display news tickers.

Available ticker styles:

- Fade:
  Smooth transition between news titles, light and JQuery-powered.
- BBC Style:
  Display news titles typewriter-like (Only links)
  Uses a JQuery plugin by Bryan Gullan
- Scroller
  Display horizontally or vertically scrolling news titles.
  Uses JScroller by Markus Bordihn
  
Put in the views tickers only short fields!

